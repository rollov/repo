# Version 1.1.1

* code refactoring
* reorganize project structure
* add StreamCloud icon image to the add-on

# Version 1.1.0

* Add multi language support (DE, EN)

# Version 1.0.7

* Fixed bug ("file not found" dialog displayed when pressing CANCEL button)
* Added CHANGELOG.md
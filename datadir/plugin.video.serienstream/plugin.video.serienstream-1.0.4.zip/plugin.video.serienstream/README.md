# SerienStream - Kodi Video Add-on

Stream series from serienstream.to

## Installation

1. Download the ZIP file from Git
2. Start your Kodi home theatre
3. Go to System -> Add-ons -> Install from zip file
4. Select the ZIP file to start the installation

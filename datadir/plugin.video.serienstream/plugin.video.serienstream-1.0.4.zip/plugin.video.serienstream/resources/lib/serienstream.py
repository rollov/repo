import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from resources.lib.url_resolver import StreamcloudResolver
from resources.lib.items.directory_item import DirectoryItem
from resources.lib.items.action_item import ActionItem
from resources.lib.items.video_item import VideoItem
from resources.lib import const, http


class SerienStream:
    def __init__(self):
        params = self.get_params(sys.argv[2])
        self.get = params.get
        self.item_list = []
        self.run()
        pass
        
    def run(self):   
        if self.get('mode') == 'settings':
            self.settings()
        elif self.get("mode") == 'search':
            self.search()
        elif self.get("mode") == 'popular':
            self.popular()
        elif self.get("mode") == 'new':
            self.new()
        elif self.get("mode") == 'catalog' and self.get("letter"):
            self.browse(self.get("letter"))
        elif self.get("mode") == 'catalog':
            self.catalog()
        elif self.get("mode") == 'seasons':
            self.seasons()
        elif self.get("mode") == 'episodes':
            self.episodes()
        elif self.get('mode') == 'play':
            self.play()
        else:
            self.navigation()

        for item in self.item_list:
            if isinstance(item, DirectoryItem):
                self.add_directory_item(item)     
            elif isinstance(item, ActionItem):
                self.add_action_item(item)
            elif isinstance(item, VideoItem):
                self.add_video_item(item)
                
        xbmcplugin.endOfDirectory(const.ADDON_HANDLE)
        pass
        
    def get_params(self, parameter_string):
        commands = {}
        split_commands = parameter_string[parameter_string.find('?')+1:]\
            .split('&')
        
        for command in split_commands:
            if len(command) > 0:
                split_command = command.split('=')
                name = split_command[0]
                value = split_command[1]
                commands[name] = value
        
        return commands
        
    def play_video(self, file_url):
        item = xbmcgui.ListItem(path=file_url)
        xbmcplugin.setResolvedUrl(const.ADDON_HANDLE, True, item)
        pass

    def add_directory_item(self, item):
        li = xbmcgui.ListItem(label=item.name, thumbnailImage=item.image)
        xbmcplugin.addDirectoryItem(
            handle=const.ADDON_HANDLE, url=const.BASE_URL + item.query,
            listitem=li, isFolder=True
        )
        pass
        
    def add_action_item(self, item):
        li = xbmcgui.ListItem(label=item.name, thumbnailImage=item.image)
        xbmcplugin.addDirectoryItem(
            handle=const.ADDON_HANDLE, url=const.BASE_URL + item.query, 
            listitem=li, isFolder=False
        )
        pass
        
    def add_video_item(self, item):
        li = xbmcgui.ListItem(label=item.title, thumbnailImage=item.image)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle=const.ADDON_HANDLE, url=const.BASE_URL + item.query, 
            listitem=li, isFolder=False
        )
        pass
        
    def settings(self):
        xbmcaddon.Addon('plugin.video.streamcloud').openSettings()
        pass

    def change_view_mode(self):
        skin_used = xbmc.getSkinDir()
        if skin_used == 'skin.confluence':
            xbmc.executebuiltin('Container.SetViewMode(500)') # "Thumbnail" view
        pass

    def navigation(self):    
        navigation = [
            {
                "name": "Search",
                "query": "?mode=search",
                "type": "directory"
            },
            {
                "name": "A-Z",
                "query": "?mode=catalog",
                "type": "directory"
            },
            {
                "name": "Popular",
                "query": "?mode=popular",
                "type": "directory"
            },
            {
                "name": "New",
                "query": "?mode=new",
                "type": "directory"
            },
        ]
        
        for item in navigation:
            if item['type'] == 'directory':
                self.item_list.append(
                    DirectoryItem(item['name'], item['query'])
                )
            elif item['type'] == 'action':
                self.item_list.append(
                    ActionItem(item['name'], item['query'])
                )
        pass
        
    def search(self):
        dialog = xbmcgui.Dialog()
        d = dialog.input('Search', type=xbmcgui.INPUT_ALPHANUM)
        obj = http.get("%s/search.php?term=%s" % (const.SERVICE_URL, d))

        for video in obj:
            self.item_list.append(
                DirectoryItem(video['title'], "?mode=seasons&title=%s" % video['urlTerm'],
                              "%s/thumbs/%s.jpg" % (const.SERVICE_URL, video['urlTerm']))
            )
        self.change_view_mode()
        pass

    def popular(self):
        obj = http.get("%s/categories.php" % const.SERVICE_URL)

        for video in obj:
            self.item_list.append(
                DirectoryItem(video['title'], "?mode=seasons&title=%s" % video['urlTerm'],
                              "%s/thumbs/%s.jpg" % (const.SERVICE_URL, video['urlTerm']))
            )
        self.change_view_mode()
        pass

    def new(self):
        obj = http.get("%s/categories.php?category=neu" % const.SERVICE_URL)

        for video in obj:
            self.item_list.append(
                DirectoryItem(video['title'], "?mode=seasons&title=%s" % video['urlTerm'],
                              "%s/thumbs/%s.jpg" % (const.SERVICE_URL, video['urlTerm']))
            )
        self.change_view_mode()
        pass

    def browse(self, letter):
        if letter == "%23":
            letter = 1

        obj = http.get("%s/search.php?letter=%s" % (const.SERVICE_URL, letter))
        
        for video in obj:
            self.item_list.append(
                DirectoryItem(video['title'], "?mode=seasons&title=%s" % video['urlTerm'],
                              "%s/thumbs/%s.jpg" % (const.SERVICE_URL, video['urlTerm']))
            )
        self.change_view_mode()
        pass             
     
    def catalog(self):
        for letter in '#ABCDEFGHIJKLMNOPQRSTUVWXYZ':
            self.item_list.append(
                DirectoryItem(letter, "?mode=catalog&type=%s&letter=%s" % (self.get('type'), letter))
            )
        pass
        
    def seasons(self):
        obj = http.get('%s/seasons.php?title=%s' % (const.SERVICE_URL, self.get('title')))
        
        for season in obj['seasons']:
            self.item_list.append(
                DirectoryItem("Season %s" % season, "?mode=episodes&title=%s&season=%s" % (self.get('title'), season))
            )
        pass
        
    def episodes(self):
        try:
            obj = http.get("%s/episodes.php?title=%s&season=%s&version=2" %
                           (const.SERVICE_URL, self.get('title'), self.get('season')))

            if len(obj['episodes']):            
                for episode in obj['episodes']:
                    self.item_list.append(
                        VideoItem(
                            "%s - %s" % (episode['id'], episode['title']),
                            "?mode=play&title=%s&season=%s&episode=%s" %
                            (self.get('title'), self.get('season'), episode['id'])
                        )
                    )
            else:
                raise Exception('Episodes not found')
        except Exception, e:
            print 'StreamCloud Error occurred: %s' % e
            dialog = xbmcgui.Dialog()
            dialog.ok("Error", "No Episodes hosted by StreamCloud in this Season")
        pass
        
    def play(self):
        # find a working mirror
        try:
            host = http.get("%s/stream.php?title=%s&season=%s&episode=%s" %
                            (const.SERVICE_URL, self.get('title'), self.get('season'), self.get('episode')))

            res = StreamcloudResolver()
            media_url = res.get_media_url(host['url'])

            if res.canceled is True:
                raise Exception('CANCELED')

            if media_url:
                self.play_video(media_url)

            if not media_url:
                raise Exception('FILE_NOT_FOUND')
                
        except Exception, e:
            print 'StreamCloud Error occurred: %s' % e
            
            if str(e) == 'FILE_NOT_FOUND':
                dialog = xbmcgui.Dialog()
                dialog.ok("StreamCloud", "File Not Found or removed")
        pass
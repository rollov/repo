class VideoItem:
    def __init__(self, title=u'', path=u'', image=u'DefaultVideo.png'):
        self.title = title
        self.path = path
        self.image = image
        pass
        
    pass
class ActionItem:
    def __init__(self, name=u'', path=u'', image=u'DefaultFolder'):
        self.name = name
        self.path = path
        self.image = image
        pass
        
    pass
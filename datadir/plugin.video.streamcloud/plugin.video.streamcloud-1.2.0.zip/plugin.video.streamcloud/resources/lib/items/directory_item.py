class DirectoryItem:
    def __init__(self, name=u'', path=u'', image=u'DefaultFolder.png'):
        self.name = name
        self.path = path
        self.image = image
        pass
        
    pass
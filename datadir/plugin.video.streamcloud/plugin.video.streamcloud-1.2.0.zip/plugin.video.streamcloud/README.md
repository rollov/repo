# StreamCloud - XBMC Video Add-on

Stream movies, series and documentations from StreamCloud.eu

## Installation

1. Download the ZIP file from Git
2. Start your XBMC
3. Go to System -> Add-ons -> Install from zip file
4. Select the ZIP file to start the installation

class VideoItem:
    def __init__(self, title=u'', query=u'', image=u'DefaultVideo.png'):
        self.title = title
        self.query = query
        self.image = image
        pass
        
    pass
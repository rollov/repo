class ActionItem:
    def __init__(self, name=u'', query=u'', image=u'DefaultFolder'):
        self.name = name
        self.query = query
        self.image = image
        pass
        
    pass